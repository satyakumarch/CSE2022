// scope resolution
// let a=10
// function name(a,b)
// {
//     let b=10
//     return a+b
// }
// // var a=20;
// console.log(a)
// result=name(3,4)
// console.log(result)
// console.log(b)
// let ch="mamta"
// console.log(typeof(ch))
// let number=[1,2,3,true,'a',4]
// for(let i=0;i<number.length,i=i+2)
// {

// }
// console.log(typeof(number))

// non primitive datatypes
// object data type
// const male={haie:"black",eyes:"brown",complexion:"white",age:20,weight:60}
// for(let i of male)
// console.log(i)

// var length=Object.keys(male).length
// for(let i=0;i<length;i++)

//  console.log(male[Object.keys(male)[i]])//for values

// console.log(male1.push())//when i  want to enter at last
// male1[0]=20//when i want to enter at a particular index
// male1.splice(3,0,4)// when i do not want to replace an index
// Loops can execute a block of code several times.
// JavaScript supports different kinds of loops:
// For loop
// While loop
// Do while loop
// For in loop
// For of loop
// function
// function display(cartoonchannel,sportschanel,...misc)
//     {
//         return misc

// }
// var chanel=display('POGO','ESPN','STARPLUS','STARSPORTS','AAJTAK')
// console.log(chanel)
// just like our rest operator we are havin three dots in spread as well 
// function dif(a,b)
// {return a-b}
// const data=[4,3]
// var diff=diff(...data)
// console.log(diff)
// var circle=(r)=>
// {
//     let PI=3.14
//     return PI*r*r
// }
// var circle=area_circle(4)
// console.log(circle)
// Importing events 
// const EventEmitter = require('events'); 

// // Initializing event emitter instances 
// var eventEmitter = new EventEmitter(); 

// // Registering to myEvent 
// eventEmitter.on('myEvent', (msg) => { 
// console.log(msg); 
// }); 

// // Triggering myEvent 
// eventEmitter.emit('myEvent', "First event"); 

// fs.access('file.txt',fs.constants.F_OK,(err)=>
// {
//     if(err)
//     {console.error("error")}
//     else
//     {console.log("i am having that file")}
// })
// read the file that is present
// fs.rename("file.txt","i am teaching nodejs",(err)=>
// {
//     if(err)
// {console.error("error")}
//     else{console.log("file is written")}
// })
// function display()
// {
//     console.log("int222")
// }
// var a=display()
// console.log(a)
// fs.stat("package.json",(err)=>
// {

// })
// const p="path  where you eant to create a folder"
// fs.mkdir(p,("err"))
// const fs=require('fs')
// fs.readFile('file.txt',(err,data)=>
// {
//     if(err)
//     {
//         console.error('error')
//     }
//     else{
//         console.log(data)
//     }
// }
// )
// const loadash=require('loadash')
// const data=[1,2,3,4,5]
// week 3 activity
 



















