var querystring = require('querystring');
var q = querystring.stringfy({year:2017,month:2});
console.log(q);
// escape
// unescape
// stringfy
// decode