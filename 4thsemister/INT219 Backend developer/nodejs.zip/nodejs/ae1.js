// // let a=null
// // let a="int222"
// // function display()
// // {
// //     console.log("hlo")
// //     let a=10
// // }
// // console.log(typeof(a))
// // console.log(name)

// // const { promptLoop } = require("readline-sync")


// // const male=["black", "brown","fair",20,true]
// // length of array
// // var l=male.lenght
// // var length=Object.keys(male).length
// // // for(let i=0;i<l;i++)
// // // {
// // //     console.log(male[Object.keys(male)[i]])
// // // }
// // for(let i in male)
// // console.log(male[i])
// // function square(a)
// // {return a*a}
// // var sq=square()
// // console.log(sq)
// // fs module
// // const fs=require('fs')
// // fs.access('file.txt',fs.constants.F_OK,(err)=>
// // {
// //     if(err)
// //     {console.error('sorry file is not there')}
// //     else{
// //         console.log('file is present')

// //     }
// // }
// // )
// // fs.readFileSync('file.txt','utf-8',(err,data)=>

// //    try
// //     {
// //         const a=fs.readFileSync('file.txt','utf-8')
// //         console.log(a)
// //     }
// // catch(e)
// // {
// //     console.error('error')
// // }

// // function square(a)
// // {return a*a}

// // const result=square(10)
// // console.log(result)
// // fs.writeFile('file.txt','content that i want',(err)=>
// // {
// // if(err)
// // {
// //     console.error('print an error')
// // }
// // else{
// //     console.log('file is updated')
// // }
// // }
// // )
// // append
// // rename('old file name','newfile name',(err))
// // open
// // close
// // copy
// // stats
// // unlink
// // check  whether give file  is an object or not
// // const route="c:/user/desktop/nodejs/test"

// // const fs=require('fs')
// // fs.readFile("au.json","utf-8",(err,data)=>
// // {if(err)
// // {
// //     console.error('error')
// // }
// // else{
// //     // const a=JSON.parse(data)
// //     console.log(JSON.parse(data))
// // }
// // }
// // )
// // const element={
    
// // }
// //  const one=Buffer(['1','2','3'])
// // its time to work with path module
// // const path=require('path')
// // const dir=path.extname("C:\Users\HP\Downloads\INT222\RE-2022-206001_plag-report.pdf")
// // console.log(dir)
// // // normalize
// // basename
// // delimiter
// // os module
// const os=require('os')
// const architecture=os.availableParallelism()
// console.log(architecture)
// // week 2 activity
// // create a json file.compress that File,
// // you have to objectify the given json Before
// // compressing it, again decompress that file
// // using the fs module read, write, rename, append
// // and copy the json file
// const  http=require('http')
// statuscode=http.STATUS_CODES
// console.log(statuscode)

// const express = require('express')
// const app = express()

// app.get('/', function (req, res) {
//   res.send('Hello World')
// })

// app.listen(3000)

// activity for third week
// create a simple js server that
// process different url and query string

// const express = require('express')
// const app = express()

// app.get('/', function (req, res) {
//   res.send('Hello World')
// })

// app.listen(3000)
ACTIVITY to Perform
// create a server and then handle URL
// and query processing.


































