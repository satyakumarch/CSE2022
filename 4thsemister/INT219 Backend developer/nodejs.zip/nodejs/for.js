 const student=['a','b','c']
// for(let i=0;i<student.length;i=i+2)
// console.log(student[i])
// for loop
// for (let i=0;i<=10;i++)
// {
//     console.log(i)


// }
// const students={rollno:1,name:"abc",marks:62,gender:'m'}
// var length=Object.keys(students).length
// for(let i=0;i<=length;i++)
// {
//     console.log()
// }
// for(let key in students)
// console.log(key,students[])
// for(let i of student)

const readline=require('readline-async')
const a=console.log('enter your name')
console.log()

