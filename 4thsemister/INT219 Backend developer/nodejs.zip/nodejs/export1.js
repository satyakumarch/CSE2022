const timer=()=>
{
    console.log('here is an example of timer')
}
// setTimeout(timer,1000,'your time')
module.exports={timer}