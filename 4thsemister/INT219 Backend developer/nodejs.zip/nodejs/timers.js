// // const water= (name) => {
// //   console.log(`${name},please switch off the motor`);
// // };

// // setTimeout(water, 5000,'mamta');
// // clearTimeout(water);
// function myFunction() {
//   console.log("Timer executed!");
// }

// const timerId = setTimeout(myFunction, 2000); // Set a timer to execute myFunction after 2 seconds

// // Clear the timer before it executes
// clearTimeout(timerId);

// Now, myFunction will not be executed
const a=require('./export1')
console.log(a.timer())
