function display()
{
    console.log("welcome to node")
}
module.exports={display}
// const fs=require('fs')
// content="no one is still interseted and talking with each other"
// fs.unlink('file.txt',function(err){
//     if(err)
//     {
//         console.error('error is present')
//     }
// else{
//     console.log("file is  erased")
// }
// }
// )
// function calculate(age)
// {
//     if(age>20)
//     {
