// var os=require('os')
// console.log("free memory of our system is"+os.freemem())

  var a=10
  function simple()
  {
    console.log('int 222')
     let sum=7
    }  
 var b=simple()
 console.log(simple())
 console.log(a)
console.log(sum)