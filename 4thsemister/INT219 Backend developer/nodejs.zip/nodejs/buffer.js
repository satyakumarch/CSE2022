//  const bufferOne = new Buffer('Happy Learning ');

// const bufferTwo = new Buffer('With GFG');
// const bufferThree = Buffer.concat([bufferOne, bufferTwo]);
// console.log(bufferThree.toString());
