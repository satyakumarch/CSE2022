// that command that you have to run
//    npm install readline-sync

const readlineSync = require('readline-sync');


const userName = readlineSync.question('enter your distance from lpu');


console.log(`${userName}, sorry!this is not good enough to teach the students of  b.tech !`);