


function trip(destination, budget, ...info)
{
    return info
}
console.log(trip('punjab','1000','3','4'))