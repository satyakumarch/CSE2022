export function sample()
{
    console.log("display")
}
