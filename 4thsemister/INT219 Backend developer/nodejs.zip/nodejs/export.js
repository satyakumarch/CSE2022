function mul(a,b)
{
    return a*b
}
module.exports={mul}
