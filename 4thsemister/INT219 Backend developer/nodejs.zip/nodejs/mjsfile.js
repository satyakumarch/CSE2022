import {sample} from './example'
sample()