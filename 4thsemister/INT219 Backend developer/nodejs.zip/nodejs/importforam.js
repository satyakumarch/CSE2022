var a=require('./exportforam')
console.log(a.display())